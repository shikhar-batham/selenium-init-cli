package __BASE_PACKAGE__.pages;

import __BASE_PACKAGE__.base.TestBase;
import __BASE_PACKAGE__.object_repo.LoginPageOR;
import com.google.inject.Inject;
import org.apache.logging.log4j.Logger;

public class LoginPage extends TestBase {

    @Inject
    private Logger log;

    public void login(String username, String password) {
        this.inputByName("username", username);
        this.inputByName("password", password);
        this.clickLoginButton();
        log.info("Logged In with Admin");
    }

    public void inputByName(String locator, String keys) {
        getElement(LoginPageOR.INP_BY_NAME_XP.getLocator().replace("$VAR", locator)).sendKeys(keys);
        log.info("Written: {}", keys);
    }

    public void clickLoginButton() {
        getElement("//button[normalize-space()='Login']").click();
        log.info("Clicked Login button");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
