package __BASE_PACKAGE__.base;

import __BASE_PACKAGE__.di.DriverModule;
import __BASE_PACKAGE__.di.LoggerModule;
import com.google.inject.Guice;
import com.google.inject.Inject;
import com.google.inject.Injector;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

public class TestBase {

    protected static final Properties properties = new Properties();
    private final String environment = System.getProperty("env.profile", "dev");
    private static final ThreadLocal<WebDriver> threadDriver = new ThreadLocal<>();

    @Inject
    private Logger log;

    protected Logger logger() {
        return log != null ? log : LogManager.getLogger(getClass());
    }

    public TestBase() {
        setupEnvironment();
    }

    private void setupEnvironment() {

        String configPath = "src/main/java/__BASE_PACKAGE__/config/config-" + environment + ".properties";
        try (FileInputStream ip = new FileInputStream(configPath)) {
            properties.load(ip);
        } catch (IOException e) {
            System.out.println("Failed To Load Environment - " + environment + "| Message - " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    @Parameters({"browser", "browserVersion"})
    @BeforeMethod
    public void setUp(@Optional("chrome") String browser, @Optional("latest") String browserVersion) {
        Injector injector = Guice.createInjector(new DriverModule(browser, browserVersion), new LoggerModule());
        injector.injectMembers(this);
        logger().info("Browser: {}", browser);
        threadDriver.set(injector.getInstance(WebDriver.class));
        getDriver().get(properties.getProperty("baseUrl"));
    }

    @AfterMethod
    public void tearDown() {
        if (getDriver() != null) {
            getDriver().quit();
            threadDriver.remove();
        }
    }

    protected WebDriver getDriver() {
        return threadDriver.get();
    }

    public WebElement getElement(String locator) {
        logLocating("xpath", locator, 5);
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(5));
        By by = By.xpath(locator);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            logFound(locator);
            return getDriver().findElement(by);
        } catch (NoSuchElementException e) {
            logError("Element not found", locator);
            Assert.fail("Element not found: " + locator + " | " + e.getMessage(), e);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (TimeoutException e) {
            logError("Timeout waiting for element", locator);
            Assert.fail("Timeout waiting for element: " + locator + " | " + e.getMessage(), e);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (Exception e) {
            logError("Unexpected error locating element", locator);
            Assert.fail("Unexpected error locating element: " + locator + " | " + e.getMessage(), e);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        }
    }

    public WebElement getElement(String locator, int waitInSec) {
        logLocating("xpath", locator, waitInSec);
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(waitInSec));
        By by = By.xpath(locator);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            logFound(locator);
            return getDriver().findElement(by);
        } catch (NoSuchElementException e) {
            logError("Element not found", locator);
            Assert.fail("Element not found: " + locator + " | " + e.getMessage(), e);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (TimeoutException e) {
            logError("Timeout waiting for element", locator);
            Assert.fail("Timeout waiting for element: " + locator + " | " + e.getMessage(), e);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (Exception e) {
            logError("Unexpected error locating element", locator);
            Assert.fail("Unexpected error locating element: " + locator + " | " + e.getMessage(), e);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        }
    }

    public List<WebElement> getElements(String locator) {
        logLocating("xpath", locator, 5);
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(5));
        By by = By.xpath(locator);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            logFound(locator);
            return getDriver().findElements(by);
        } catch (NoSuchElementException e) {
            logError("Elements not found", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (TimeoutException e) {
            logError("Timeout waiting for elements", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (Exception e) {
            logError("Unexpected error locating elements", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        }
    }

    public List<WebElement> getElementsByCssSelector(String locator) {
        logLocating("css", locator, 5);
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(5));
        By by = By.cssSelector(locator);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            logFound(locator);
            return getDriver().findElements(by);
        } catch (NoSuchElementException e) {
            logError("Elements not found", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (TimeoutException e) {
            logError("Timeout waiting for elements", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (Exception e) {
            logError("Unexpected error locating elements", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        }
    }

    public WebElement getElementByCssSelector(String locator) {
        logLocating("css", locator, 10);
        try {
            WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(locator)));
            logFound(locator);
            return element;
        } catch (NoSuchElementException e) {
            logError("Element not found", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (TimeoutException e) {
            logError("Timeout waiting for element", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (Exception e) {
            logError("Unexpected error locating element", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        }
    }

    public List<WebElement> getElements(String locator, int waitInSec) {
        logLocating("xpath", locator, waitInSec);
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(waitInSec));
        By by = By.xpath(locator);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            logFound(locator);
            return getDriver().findElements(by);
        } catch (NoSuchElementException e) {
            logError("Elements not found", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (TimeoutException e) {
            logError("Timeout waiting for elements", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        } catch (Exception e) {
            logError("Unexpected error locating elements", locator);
            throw new RuntimeException(e.getStackTrace()[0].getMethodName().trim() + e.getMessage().substring(0, 100));
        }
    }

    private void logLocating(String strategy, String locator, int timeoutSec) {
        logger().info("Locating | strategy: {} | locator: {} | timeout: {}s", strategy, locator, timeoutSec);
    }

    private void logFound(String locator) {
        logger().info("Found | locator: {}", locator);
    }

    private void logError(String reason, String locator) {
        logger().error("{} | locator: {}", reason, locator);
    }
}
