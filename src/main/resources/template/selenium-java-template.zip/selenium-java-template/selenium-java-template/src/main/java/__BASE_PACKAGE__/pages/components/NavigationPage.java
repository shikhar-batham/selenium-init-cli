package __BASE_PACKAGE__.pages.components;

import __BASE_PACKAGE__.base.TestBase;
import __BASE_PACKAGE__.object_repo.NavigationPageOR;

public class NavigationPage extends TestBase {

    public void navigate(String pageName) {
        getElement(NavigationPageOR.SPAN_BY_TEXT_XP.getLocator()
                .replace("$VAR", pageName)
        ).click();
    }
}
