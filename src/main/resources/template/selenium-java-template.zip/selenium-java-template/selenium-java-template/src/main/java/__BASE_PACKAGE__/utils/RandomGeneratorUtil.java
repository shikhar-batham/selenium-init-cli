package __BASE_PACKAGE__.utils;

import java.security.SecureRandom;
import java.util.Random;

public class RandomGeneratorUtil {

    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final SecureRandom RANDOM = new SecureRandom();

    private RandomGeneratorUtil() {
    }

    public static long generateRandomNumber(int desiredDigits) {

        if (desiredDigits <= 0 || desiredDigits >= 11) desiredDigits = 10;

        return generateRandomNumberUtil(desiredDigits);
    }

    public static long generateRandomNumber() {
        return generateRandomNumberUtil(10);
    }

    public static String generateRandomString(int desiredLength) {
        return desiredLength <= 0 ? null : generateRandomStringUtil(desiredLength);
    }

    public static String generateRandomString() {
        return generateRandomStringUtil(10);
    }


    private static long generateRandomNumberUtil(int desiredDigits) {

        long smallestNumberWithDesiredDigits = (long) Math.pow(10, desiredDigits - 1);
        long maximumNumberWithDesiredDigits = (long) Math.pow(10, desiredDigits) - 1;

        return smallestNumberWithDesiredDigits + (long) (Math.random() * (maximumNumberWithDesiredDigits - smallestNumberWithDesiredDigits + 1));
    }

    private static String generateRandomStringUtil(int desiredLength) {

        StringBuilder stringBuilder = new StringBuilder(desiredLength);
        for (int i = 0; i < desiredLength; i++) {
            int randomIndex = RANDOM.nextInt(CHARACTERS.length());
            stringBuilder.append(CHARACTERS.charAt(randomIndex));
        }

        return stringBuilder.toString();
    }

    public static String cleanString(String input) {
        if (input == null || input.isEmpty()) return input;
        return input.replaceAll("[^a-zA-Z0-9\\s\\-_.,]", "");
    }

    public static String generateRandomStringOfDesiredLength(int length) {
        if (length < 1) {
            throw new IllegalArgumentException("Length must be at least 1");
        }

        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            char randomChar = (char) ('a' + random.nextInt(26));
            sb.append(randomChar);
        }
        return sb.toString();
    }
}
