package __BASE_PACKAGE__.constants;

public enum Credentials {

    USERNAME("Admin"),
    PASSWORD("admin123");

    private final String cred;

    Credentials(String cred) {
        this.cred = cred;
    }

    public String getCred() {
        return cred;
    }
}
