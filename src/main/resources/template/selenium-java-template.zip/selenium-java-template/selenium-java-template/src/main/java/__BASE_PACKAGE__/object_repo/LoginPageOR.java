package __BASE_PACKAGE__.object_repo;

public enum LoginPageOR {

    INP_BY_NAME_XP("//input[@name='$VAR']");

    private final String locator;

    LoginPageOR(String locator) {
        this.locator = locator;
    }

    public String getLocator() {
        return locator;
    }
}
