package __BASE_PACKAGE__.listeners;

import __BASE_PACKAGE__.base.TestBase;
import com.google.inject.Inject;
import org.apache.logging.log4j.Logger;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryAnalyzer extends TestBase implements IRetryAnalyzer {

    @Inject
    private Logger log;

    int counter = 0;
    int retryLimit = 0;

    @Override
    public boolean retry(ITestResult iTestResult) {
        while (counter < retryLimit) {
            log.info("Re-executing test method: {}", iTestResult.getMethod().getMethodName());
            counter++;
            return true;
        }
        return false;
    }
}
