package __BASE_PACKAGE__.di;

import com.google.inject.MembersInjector;
import org.apache.logging.log4j.LogManager;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;

public class Log4jMembersInjector<T> implements MembersInjector<T> {

    private final Field field;
    private final Object logger;

    public Log4jMembersInjector(Field field) {
        this.field = field;
        if (field.getType() == org.apache.logging.log4j.Logger.class) {
            this.logger = LogManager.getLogger(field.getDeclaringClass());
        } else {
            this.logger = LoggerFactory.getLogger(field.getDeclaringClass());
        }
        field.setAccessible(true);
    }

    @Override
    public void injectMembers(T instance) {
        try {
            field.set(instance, logger);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
