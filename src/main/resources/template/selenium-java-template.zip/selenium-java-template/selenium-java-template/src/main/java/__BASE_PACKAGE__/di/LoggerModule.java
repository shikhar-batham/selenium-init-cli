package __BASE_PACKAGE__.di;

import com.google.inject.AbstractModule;
import com.google.inject.Inject;
import com.google.inject.TypeLiteral;
import com.google.inject.matcher.Matchers;
import com.google.inject.spi.TypeEncounter;
import com.google.inject.spi.TypeListener;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;

public class LoggerModule extends AbstractModule {

    private static final Class<?> SLF4J_LOGGER = org.slf4j.Logger.class;
    private static final Class<?> LOG4J_LOGGER = Logger.class;

    @Override
    protected void configure() {
        // Fallback bindings satisfy Guice validation; TypeListener overrides with class-specific loggers
        bind(Logger.class).toInstance(LogManager.getRootLogger());
        bind(org.slf4j.Logger.class).toInstance(LoggerFactory.getLogger(LoggerModule.class));

        bindListener(Matchers.any(), new TypeListener() {
            @Override
            public <I> void hear(TypeLiteral<I> type, TypeEncounter<I> encounter) {
                Class<?> clazz = type.getRawType();
                while (clazz != null) {
                    for (Field field : clazz.getDeclaredFields()) {
                        if (field.isAnnotationPresent(Inject.class) &&
                                (field.getType() == LOG4J_LOGGER || field.getType() == SLF4J_LOGGER)) {
                            encounter.register(new Log4jMembersInjector<>(field));
                        }
                    }
                    clazz = clazz.getSuperclass();
                }
            }
        });
    }
}
