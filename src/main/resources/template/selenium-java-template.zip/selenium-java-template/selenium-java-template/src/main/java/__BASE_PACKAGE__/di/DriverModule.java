package __BASE_PACKAGE__.di;

import com.google.inject.AbstractModule;
import com.google.inject.Provides;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.time.Duration;

public class DriverModule extends AbstractModule {

    private final String browser;
    private final String browserVersion;
    private WebDriver driver;

    public DriverModule(String browser, String browserVersion) {
        this.browser = browser;
        this.browserVersion = browserVersion;
    }

    private boolean isSpecificVersion() {
        return browserVersion != null && !browserVersion.equalsIgnoreCase("latest");
    }

    private void setupDriverManager(WebDriverManager wdm) {
        if (isSpecificVersion()) wdm.browserVersion(browserVersion);
        wdm.setup();
    }

    private WebDriver createChromeDriver() {
        setupDriverManager(WebDriverManager.chromedriver());
        ChromeOptions options = new ChromeOptions();
        if (isSpecificVersion()) options.setBrowserVersion(browserVersion);
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--user-data-dir=" + System.getProperty("java.io.tmpdir") + "/chrome-profile-" + Thread.currentThread().getId() + "-" + System.nanoTime());
        return new ChromeDriver(options);
    }

    private WebDriver createEdgeDriver() {
        setupDriverManager(WebDriverManager.edgedriver());
        EdgeOptions options = new EdgeOptions();
        if (isSpecificVersion()) options.setBrowserVersion(browserVersion);
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--user-data-dir=" + System.getProperty("java.io.tmpdir") + "/edge-profile-" + Thread.currentThread().getId() + "-" + System.nanoTime());
        return new EdgeDriver(options);
    }

    private WebDriver createFirefoxDriver() {
        setupDriverManager(WebDriverManager.firefoxdriver());
        FirefoxOptions options = new FirefoxOptions();
        if (isSpecificVersion()) options.setBrowserVersion(browserVersion);
        options.setBinary("/usr/bin/firefox");
        options.enableBiDi();
        return new FirefoxDriver(options);
    }

    @Provides
    public WebDriver provideWebDriver() {
        if (browser.equalsIgnoreCase("chrome")) {
            driver = createChromeDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
            driver = createEdgeDriver();
        } else if (browser.equalsIgnoreCase("firefox")) {
            driver = createFirefoxDriver();
        } else {
            throw new IllegalArgumentException("Unsupported browser: " + browser);
        }

        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        return driver;
    }
}
