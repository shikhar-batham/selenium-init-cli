# selenium-java-template

A production-ready Selenium + Java + TestNG automation framework with Page Object Model structure, Allure reporting, and config-driven environment support.

---

## Prerequisites

- Java 21
- Maven
- Allure CLI 2.x ([Installation Guide](https://github.com/allure-framework/allure2/releases))

---

## Running Tests

Execute tests on the **Dev** environment:

```bash
mvn clean test -Pdev
```

Execute tests on the **Stage** environment:

```bash
mvn clean test -Pstage
```

---

## Generating Allure Report

After test execution, generate the report:

```bash
allure generate --single-file
```

```bash
allure serve target/allure-results
```

> **Note:** `--single-file` flag requires Allure CLI 2.x. Make sure your CLI version matches the `allure-testng` dependency version in `pom.xml`.

---

## Project Structure
[Downloads](..%2F..%2FDownloads)
```
src/
├── main/java/
│   ├── pages/          # Page Object classes
│   ├── components/     # Reusable UI components
│   └── utils/          # Utility classes and common wrappers
├── test/java/
│   └── tests/          # Test classes
└── resources/
    ├── config/         # Environment profiles (dev, stage)
    └── testng.xml      # TestNG suite configuration
```

---

## Tech Stack

| Tool | Purpose |
|------|---------|
| Selenium WebDriver | Browser automation |
| Java | Programming language |
| TestNG | Test framework |
| Maven | Build and dependency management |
| Allure | Test reporting |

---

## Contributing

Open to contributions and suggestions. Feel free to open an issue or submit a pull request.