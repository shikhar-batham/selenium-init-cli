package __BASE_PACKAGE__;

import __BASE_PACKAGE__.base.TestBase;
import org.testng.annotations.Test;

public class LoginPageTest extends TestBase {

    @Test
    void firstTest(){

    }
}
