package __BASE_PACKAGE__;

import __BASE_PACKAGE__.base.TestBase;
import __BASE_PACKAGE__.pages.LoginPage;
import com.google.inject.Inject;
import io.qameta.allure.*;
import io.qameta.allure.testng.Tag;
import io.qameta.allure.testng.Tags;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

@Epic("Login")
public class LoginPageTest extends TestBase {

    @Inject
    private LoginPage loginPage;
    @Inject
    private Logger log;

    @Severity(SeverityLevel.MINOR)
    @Feature("Feature - Login")
    @Story("Story")
    @Description("Test Description")
    @Owner("Shikhar Batham")
    @Tags({@Tag("Navigation"), @Tag("Dashboard")})
    @Test(description = "Verify Login Functionality")
    void loginTest() {
        log.info("-->Logging In with: Admin");
        loginPage.inputByName("username", "Admin");
        loginPage.inputByName("password", "admin123");
        loginPage.clickLoginButton();

        log.info("-->Logged In with: Admin");
    }
}
