package __BASE_PACKAGE__.base;

import __BASE_PACKAGE__.constants.Urls;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;

public class TestBase {

    private static final ThreadLocal<WebDriver> threadDriver = new ThreadLocal<>();
    private WebDriver driver;

    public static WebDriver getDriver() {
        return threadDriver.get();
    }

    public WebElement getElement(String locator) {
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(5));
        By by = By.xpath(locator);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            return getDriver().findElement(by);
        } catch (NoSuchElementException e) {
            Assert.fail("Element not found: " + locator + " | " + e.getCause(), e);
        } catch (TimeoutException e) {
            Assert.fail("Timeout waiting for element: " + locator + " | " + e.getCause(), e);
        } catch (Exception e) {
            Assert.fail("Unexpected error locating element: " + locator + " | " + e.getCause(), e);
        }
        return null;
    }

    public void initialization() {
        driver = new ChromeDriver();
        WebDriverManager.chromedriver().setup();
        threadDriver.set(driver);
        getDriver().manage().window().maximize();
        getDriver().manage().deleteAllCookies();
        getDriver().manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        getDriver().get(Urls.BASE_APP_URL.getUrl());
    }

    @BeforeMethod
    public void setUp(){
        initialization();
    }

    @AfterMethod
    public void tearDown(){
        getDriver().quit();
        threadDriver.remove();
    }
}
