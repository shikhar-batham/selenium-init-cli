package __BASE_PACKAGE__.listeners;

import __BASE_PACKAGE__.base.TestBase;
import io.qameta.allure.Allure;
import io.qameta.allure.model.Status;
import io.qameta.allure.model.StatusDetails;
import io.qameta.allure.model.StepResult;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.IAnnotationTransformer;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.ITestAnnotation;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.List;

public class Transformer extends TestBase implements IAnnotationTransformer, ITestListener {

    @Override
    public void onTestFailure(ITestResult result) {

        byte[] screenshot = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.BYTES);
        Allure.getLifecycle().addAttachment(
                "Screenshot - " + result.getMethod().getMethodName(),
                "image/png",
                "png",
                screenshot
        );

        String fileName = System.getProperty("user.dir") + File.separator + "screenshots" + File.separator + result.getMethod().getMethodName();

        TakesScreenshot takesScreenshot = (TakesScreenshot) getDriver();
        File srcFile = takesScreenshot.getScreenshotAs(OutputType.FILE);

        try {
            FileUtils.copyFile(srcFile, new File(fileName + ".png"));
        } catch (IOException e) {
            logger().error("Could not copy source file to destination file | Message: {}", e.getMessage());
        }
    }

    @Override
    public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {
        annotation.setTimeOut(600000);
        annotation.setRetryAnalyzer(RetryAnalyzer.class);
    }

    @Override
    public void onTestStart(ITestResult result) {
        ITestListener.super.onTestStart(result);
        logger().info("Starting test case: {}", result.getMethod().getDescription());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        ITestListener.super.onTestSuccess(result);
        logger().info("Test case passed: {}", result.getMethod().getDescription());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        ITestListener.super.onTestSkipped(result);
        logger().info("Test case skipped: {}", result.getMethod().getDescription());
    }

    @Override
    public void onTestFailedWithTimeout(ITestResult result) {
        ITestListener.super.onTestFailedWithTimeout(result);
        logger().info("Test case failed with timeout: {}", result.getMethod().getDescription());
    }

    private void clearStepStatuses(List<StepResult> steps) {
        if (steps == null) return;
        for (StepResult step : steps) {
            step.setStatus(Status.PASSED);
            step.setStatusDetails(new StatusDetails());
            clearStepStatuses(step.getSteps());
        }
    }
}
