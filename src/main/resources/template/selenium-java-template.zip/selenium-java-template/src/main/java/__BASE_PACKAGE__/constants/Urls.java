package __BASE_PACKAGE__.constants;

import lombok.Getter;

@Getter
public enum Urls {

    BASE_APP_URL("https://subhgathbandhanmatrimony.com/login");

    private final String url;
    Urls(String url){
        this.url=url;
    }
}
