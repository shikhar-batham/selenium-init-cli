package __BASE_PACKAGE__.object_repo;

public enum NavigationPageOR {

    SPAN_BY_TEXT_XP("//span[normalize-space()='$VAR']");

    private final String locator;

    NavigationPageOR(String locator) {
        this.locator = locator;
    }

    public String getLocator() {
        return locator;
    }
}
